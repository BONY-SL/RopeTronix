package com.RopeTronix.RopeTronix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RopeTronixApplicationTests {

	@Test
	void contextLoads() {
	}

}
